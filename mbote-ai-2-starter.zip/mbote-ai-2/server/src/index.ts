import 'dotenv/config'
import express from 'express'
import cors from 'cors'
import OpenAI from 'openai'
import { createClient } from '@supabase/supabase-js'
import { z } from 'zod'

const app=express()
app.use(cors({origin:process.env.CLIENT_ORIGIN?.split(',')||true}))
app.use(express.json({limit:'1mb'}))
const port=Number(process.env.PORT||4000)
const openai=process.env.OPENAI_API_KEY?new OpenAI({apiKey:process.env.OPENAI_API_KEY}):null
const supabase=process.env.SUPABASE_URL&&process.env.SUPABASE_SERVICE_ROLE_KEY?createClient(process.env.SUPABASE_URL,process.env.SUPABASE_SERVICE_ROLE_KEY,{auth:{persistSession:false}}):null

// Vérifie le jeton Supabase pour chaque route privée. Ne jamais faire confiance à un user_id envoyé par le navigateur.
async function auth(req:any,res:any,next:any){
  if(!supabase)return res.status(503).json({error:'Le serveur Supabase n’est pas configuré.'})
  const token=(req.headers.authorization||'').replace(/^Bearer /,'')
  if(!token)return res.status(401).json({error:'Connexion requise.'})
  const {data,error}=await supabase.auth.getUser(token)
  if(error||!data.user)return res.status(401).json({error:'Session invalide.'})
  req.user=data.user;next()
}
app.get('/api/health',(_req,res)=>res.json({ok:true,service:'Mboté AI API'}))

const aiSchemas:any={
  advertisement:z.object({product:z.string().min(1).max(120),price:z.string().optional(),audience:z.string().max(160).optional(),benefit:z.string().max(300).optional(),contact:z.string().max(160).optional()}),
  description:z.object({product:z.string().min(1).max(120),details:z.string().max(1200).optional(),price:z.string().optional()}),
  reply:z.object({question:z.string().min(1).max(2000),info:z.string().max(1200).optional(),tone:z.enum(['chaleureux','professionnel','court']).default('chaleureux')})
}
const prompts:any={
 advertisement:(x:any)=>`Rédige une publicité vendeuse en français pour un commerçant à Brazzaville. Produit: ${x.product}. Prix: ${x.price||'non précisé'} FCFA. Cible: ${x.audience||'grand public'}. Avantage: ${x.benefit||'non précisé'}. Contact: ${x.contact||'inviter à écrire au vendeur'}. Fais un texte prêt pour WhatsApp/Facebook, naturel, honnête, avec appel à l'action. N'invente aucune caractéristique.`,
 description:(x:any)=>`Rédige une fiche produit claire et attractive en français. Produit: ${x.product}. Détails fournis: ${x.details||'aucun'}. Prix: ${x.price||'non précisé'} FCFA. N'invente aucune caractéristique; termine par un appel à l'action.`,
 reply:(x:any)=>`Aide un commerçant à répondre à ce client en français. Message client: ${x.question}. Informations confirmées sur le commerce: ${x.info||'aucune'}. Ton: ${x.tone}. Ne promets rien qui n'est pas confirmé. Si une information manque, formule une réponse prudente.`
}
for(const [kind,schema] of Object.entries(aiSchemas)){
 app.post(`/api/ai/${kind}`,auth,async(req:any,res:any)=>{
  const parsed=schema.safeParse(req.body)
  if(!parsed.success)return res.status(400).json({error:'Vérifie les informations saisies.'})
  if(!openai)return res.status(503).json({error:'La clé API IA n’est pas configurée sur le serveur.'})
  try{
   const result=await openai.chat.completions.create({model:process.env.OPENAI_MODEL||'gpt-4o-mini',messages:[{role:'system',content:'Tu es Mboté AI, assistant commercial fiable pour les petites entreprises francophones. Réponds en français, clairement et sans inventer.'},{role:'user',content:prompts[kind](parsed.data)}],temperature:0.7,max_tokens:700})
   res.json({text:result.choices[0]?.message?.content||''})
  }catch(err){console.error(err);res.status(502).json({error:'Le service IA est momentanément indisponible.'})}
 })
}
app.use('/api',auth)
app.get('/api/products',async(req:any,res)=>{const {data,error}=await supabase!.from('products').select('*').eq('user_id',req.user.id).order('created_at',{ascending:false});if(error)return res.status(500).json({error:error.message});res.json({items:data})})
app.post('/api/products',async(req:any,res)=>{const schema=z.object({name:z.string().min(1).max(120),unit_price:z.number().nonnegative(),unit_cost:z.number().nonnegative(),stock:z.number().int().nonnegative()});const p=schema.safeParse(req.body);if(!p.success)return res.status(400).json({error:'Données produit invalides.'});const {data,error}=await supabase!.from('products').insert({...p.data,user_id:req.user.id}).select().single();if(error)return res.status(400).json({error:error.message});res.status(201).json({item:data})})
app.get('/api/sales',async(req:any,res)=>{const {data,error}=await supabase!.from('sales').select('*, products(name)').eq('user_id',req.user.id).order('created_at',{ascending:false});if(error)return res.status(500).json({error:error.message});res.json({items:data})})
app.post('/api/sales',async(req:any,res)=>{const p=z.object({product_id:z.string().uuid(),quantity:z.number().int().positive(),unit_price:z.number().nonnegative()}).safeParse(req.body);if(!p.success)return res.status(400).json({error:'Données de vente invalides.'});const {data:product,error:pe}=await supabase!.from('products').select('*').eq('id',p.data.product_id).eq('user_id',req.user.id).single();if(pe||!product)return res.status(404).json({error:'Produit introuvable.'});if(product.stock<p.data.quantity)return res.status(400).json({error:'Stock insuffisant.'});const total=p.data.quantity*p.data.unit_price;const profit=p.data.quantity*(p.data.unit_price-product.unit_cost);const {data,error}=await supabase!.from('sales').insert({user_id:req.user.id,product_id:product.id,quantity:p.data.quantity,unit_price:p.data.unit_price,total_amount:total,profit}).select().single();if(error)return res.status(400).json({error:error.message});const {error:updateError}=await supabase!.from('products').update({stock:product.stock-p.data.quantity}).eq('id',product.id).eq('user_id',req.user.id);if(updateError)return res.status(500).json({error:'Vente créée mais mise à jour du stock à vérifier.'});res.status(201).json({item:data})})
app.get('/api/expenses',async(req:any,res)=>{const {data,error}=await supabase!.from('expenses').select('*').eq('user_id',req.user.id).order('created_at',{ascending:false});if(error)return res.status(500).json({error:error.message});res.json({items:data})})
app.post('/api/expenses',async(req:any,res)=>{const p=z.object({label:z.string().min(1).max(160),amount:z.number().nonnegative()}).safeParse(req.body);if(!p.success)return res.status(400).json({error:'Dépense invalide.'});const {data,error}=await supabase!.from('expenses').insert({...p.data,user_id:req.user.id}).select().single();if(error)return res.status(400).json({error:error.message});res.status(201).json({item:data})})
app.listen(port,()=>console.log(`Mboté AI API disponible sur http://localhost:${port}`))
