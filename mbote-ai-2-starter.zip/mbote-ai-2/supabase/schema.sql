-- À exécuter dans SQL Editor de Supabase.
create extension if not exists pgcrypto;

create table if not exists public.products (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  name text not null check (char_length(name) between 1 and 120),
  unit_price numeric(14,2) not null default 0 check (unit_price >= 0),
  unit_cost numeric(14,2) not null default 0 check (unit_cost >= 0),
  stock integer not null default 0 check (stock >= 0),
  created_at timestamptz not null default now()
);
create table if not exists public.sales (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  product_id uuid not null references public.products(id),
  quantity integer not null check (quantity > 0),
  unit_price numeric(14,2) not null check (unit_price >= 0),
  total_amount numeric(14,2) not null,
  profit numeric(14,2) not null,
  created_at timestamptz not null default now()
);
create table if not exists public.expenses (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  label text not null,
  amount numeric(14,2) not null check (amount >= 0),
  created_at timestamptz not null default now()
);
alter table public.products enable row level security;
alter table public.sales enable row level security;
alter table public.expenses enable row level security;
create policy "own products" on public.products for all using (auth.uid() = user_id) with check (auth.uid() = user_id);
create policy "own sales" on public.sales for all using (auth.uid() = user_id) with check (auth.uid() = user_id);
create policy "own expenses" on public.expenses for all using (auth.uid() = user_id) with check (auth.uid() = user_id);
create index if not exists products_user_idx on public.products(user_id);
create index if not exists sales_user_idx on public.sales(user_id);
create index if not exists expenses_user_idx on public.expenses(user_id);
