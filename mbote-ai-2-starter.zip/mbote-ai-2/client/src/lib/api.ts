import { supabase } from './supabase'
const API = import.meta.env.VITE_API_URL || 'http://localhost:4000'
async function authHeaders() {
  const { data } = await supabase?.auth.getSession() || { data: { session: null } }
  const token = data.session?.access_token
  return token ? { Authorization: `Bearer ${token}` } : {}
}
export async function generate(kind: string, payload: Record<string, unknown>) {
  const response = await fetch(`${API}/api/ai/${kind}`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', ...(await authHeaders()) },
    body: JSON.stringify(payload)
  })
  const data = await response.json()
  if (!response.ok) throw new Error(data.error || 'Une erreur est survenue.')
  return data.text as string
}
export async function request(path: string, options: RequestInit = {}) {
  const response = await fetch(`${API}${path}`, {
    ...options,
    headers: { 'Content-Type': 'application/json', ...(await authHeaders()), ...(options.headers || {}) }
  })
  const data = await response.json()
  if (!response.ok) throw new Error(data.error || 'Erreur serveur')
  return data
}
