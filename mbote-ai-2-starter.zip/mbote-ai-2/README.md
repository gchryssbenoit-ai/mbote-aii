# Mboté AI 2.0 — base de développement

Cette version reprend les quatre outils du prototype HTML fourni et pose une base full-stack :
- interface React responsive installable comme PWA ;
- API Node/Express ;
- génération IA via OpenAI côté serveur ;
- authentification Supabase ;
- catalogue produits, ventes, dépenses et schéma PostgreSQL avec RLS.

## Prérequis
Node.js 20+ et un projet Supabase. Une clé API OpenAI est nécessaire pour activer les générations IA.

## Installation
1. Copier `client/.env.example` vers `client/.env.local` et renseigner les variables Supabase + URL API.
2. Copier `server/.env.example` vers `server/.env` et renseigner les clés privées.
3. Dans Supabase > SQL Editor, exécuter `supabase/schema.sql`.
4. À la racine : `npm install`
5. Lancer : `npm run dev`
6. Interface : http://localhost:5173 ; API : http://localhost:4000/api/health

## Sécurité importante
- Ne jamais mettre `OPENAI_API_KEY` ou `SUPABASE_SERVICE_ROLE_KEY` dans le client.
- Le serveur vérifie le jeton Supabase pour les routes privées.
- Les tables ont des politiques RLS. Le backend utilise la clé service role après vérification du jeton et filtre chaque requête par l'identifiant authentifié.
- En production, limiter CORS à ton domaine, ajouter limitation de débit, journalisation, sauvegardes, validation de coûts et tests de sécurité.
- Prévoir un mécanisme transactionnel SQL pour enregistrer une vente et décrémenter le stock atomiquement avant mise en production à grande échelle.

## Limites de cette livraison
C'est une base fonctionnelle de développement, pas un service déjà déployé. Les clés et projets externes ne sont pas fournis. Les paiements Mobile Money, abonnements, notifications, export PDF, rôles employés, et synchronisation hors ligne complète restent à intégrer et tester. La PWA peut être installée depuis un navigateur compatible ; ce n'est pas encore une application native publiée sur Play Store/App Store.

## Étapes recommandées avant lancement
1. Configurer Supabase et OpenAI.
2. Tester inscription/connexion et isolation des données entre deux comptes.
3. Ajouter transaction SQL atomique pour les ventes.
4. Ajouter rate limiting et quotas IA par abonnement.
5. Intégrer un prestataire de paiement disponible au Congo après vérification de ses API et conditions.
6. Tester sur Android et iOS, puis déployer.
